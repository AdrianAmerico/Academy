package Aluno;
public class Pacotes {
    private String Black = "Black: Acesso ilimitado e acompanhamento por Aplicativo";
    public Pacotes(){}

    public String getSmart() {
        String smart = "Smart: Acesso uma vez ao dia a Academia";
        return smart;
    }

    public String getBlack() {
        return Black;
    }
}

