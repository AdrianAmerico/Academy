package Aluno;
import Aluno.Pacotes;
import java.util.ArrayList;
import java.util.Scanner;
public class Aluno {
    private static String nome;
    private static Integer idade;
    private static String cpf;
    private static double peso;
    private static double altura;
    private static String pacote;

    public Aluno(String nome, String cpf, Integer idade, double peso, double altura, String pacote){
            this.nome = nome;
            this.idade = idade;
            this.peso = peso;
            this.altura = altura;
            this.cpf = cpf;
            this.pacote = pacote;
        }

        public String getNome () {
            return nome;
        }

        public void setNome (String nome){
            this.nome = nome;
        }

        public int getIdade () {
            return idade;
        }

        public void setIdade ( int idade){
            this.idade = idade;
        }

        public String getCpf () {
            return cpf;
        }

        public void setCpf (String cpf){
            this.cpf = cpf;
        }

        public double getPeso () {
            return peso;
        }

        public void setPeso ( double peso){
            this.peso = peso;
        }

        public double getAltura () {
            return altura;
        }

        public void setAltura ( double altura){
            this.altura = altura;
        }

        public String getPacote () {
            return pacote;
        }

        public void setPacote (String pacote){
            this.pacote = pacote;
        }
        public String toString() {
            return
                    "NOME DO ALUNO: " + nome + "\n" +
                            "IDADE DO ALUNO: " + idade + "\n" +
                            "CPF: " + cpf + "\n" +
                            "PESO: " + peso + "\n" +
                            "ALTURA: " + altura + "\n" +
                            "PACOTE: " + pacote + "\n";
        }
       public static void cadastrarAluno(ArrayList<Aluno> alunos) {

            Scanner scanner = new Scanner(System.in);
            Pacotes pacote = new Pacotes();
            System.out.println("================");
            System.out.println("Cadastro de Alunos(a)");
            System.out.print("Nome do Aluno: ");
            nome = scanner.nextLine();
            System.out.print("CPF do Aluno: ");
            cpf = scanner.next();
            System.out.print("Idade do Aluno: ");
            idade = scanner.nextInt();
            System.out.print("Peso do Aluno: ");
            peso = scanner.nextDouble();
            System.out.print("Altura do Aluno: ");
            altura = scanner.nextDouble();
            System.out.print("Status do Aluno: true para Ativo, false para Inativo: ");
            boolean status = scanner.nextBoolean();
            System.out.println("Digite o Pano do Aluno");
            System.out.println("1 - Smart");
            System.out.println("2 - Black");
            int v1 = scanner.nextInt();
            while (v1 < 1 || v1 > 2) {
                System.out.println("Digite um Valor Válido");
                System.out.println("1 - Smart");
                System.out.println("2 - Black");
                if(v1 == 1){
                    status = true;
                } if (v1 == 2){
                    status = false;
                }
            }

            Aluno aluno = new Aluno(nome, cpf, idade, peso, altura, pacote.getSmart());
            alunos.add(aluno);
            scanner.close();
           System.out.println("Fim");
    }
}